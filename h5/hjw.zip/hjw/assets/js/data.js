var headimgList = [];

for(var i =0 ;i<100;i++){
    headimgList.push({
        headimgurl:'./assets/images/'+(i+1)+'.jpg'
    })
}